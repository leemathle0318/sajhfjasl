#import "Receiver.h"
#import "MediaBus.h"
#import <CoreImage/CoreImage.h>
#include "core/Timeline.hpp"
#include <array>
#include <vector>
#include <cstring>
#include <cmath>

BOOL OBEnabled(void) {
    auto mapping = OBBusConsumer();
    return mapping && mapping->data->fresh(uint64_t(OBNow() * 1000000));
}

BOOL OBReplaceVideo(CMSampleBufferRef sample) {
    if (!OBEnabled() || !sample) return NO;
    CVPixelBufferRef dest = CMSampleBufferGetImageBuffer(sample);
    if (!dest) { return NO; }
    // Work on the existing image buffer at the system BWNodeOutput boundary.
    OSType type = CVPixelBufferGetPixelFormatType(dest);
    if (type != kCVPixelFormatType_32BGRA && type != kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange &&
        type != kCVPixelFormatType_420YpCbCr8BiPlanarFullRange) { return NO; }
    auto chosen = OBBusCopyVideo();
    if (!chosen) return NO; // Fail open explicitly; this is not a privacy barrier.
    static CIContext *context; static dispatch_once_t once;
    dispatch_once(&once, ^{ context = [CIContext contextWithOptions:@{kCIContextUseSoftwareRenderer: @NO}]; });
    @try {
        CIImage *image = [CIImage imageWithCVPixelBuffer:chosen->pixel];
        CGRect from = image.extent;
        CGFloat width = CVPixelBufferGetWidth(dest), height = CVPixelBufferGetHeight(dest);
        // A portrait OBS canvas enters the usual landscape sensor buffer. Camera
        // orientation metadata still belongs to the original capture session.
        if ((from.size.width < from.size.height) != (width < height)) {
            image = [image imageByApplyingOrientation:6]; from = image.extent;
        }
        image = [image imageByApplyingTransform:CGAffineTransformMakeTranslation(-from.origin.x, -from.origin.y)];
        CGFloat scale = MAX(width / from.size.width, height / from.size.height);
        image = [image imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
        image = [image imageByApplyingTransform:CGAffineTransformMakeTranslation(
            (width - from.size.width * scale) / 2, (height - from.size.height * scale) / 2)];
        CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
        [context render:image toCVPixelBuffer:dest bounds:CGRectMake(0, 0, width, height) colorSpace:space];
        CGColorSpaceRelease(space); return YES;
    } @catch (NSException *exception) { (void)exception; return NO; }
}

BOOL OBMixABL(AudioBufferList *abl, UInt32 frames, const AudioStreamBasicDescription *f, double time) {
    if (!OBEnabled() || !abl || !f || f->mFormatID != kAudioFormatLinearPCM ||
        abl->mNumberBuffers > 8 || f->mChannelsPerFrame > 8 ||
        (f->mFormatFlags & kAudioFormatFlagIsBigEndian) || !(f->mFormatFlags & kAudioFormatFlagIsPacked)) return NO;
    obs::PCMKind kind;
    if ((f->mFormatFlags & kAudioFormatFlagIsFloat) && f->mBitsPerChannel == 32) kind = obs::PCMKind::Float32;
    else if ((f->mFormatFlags & kAudioFormatFlagIsSignedInteger) && f->mBitsPerChannel == 16) kind = obs::PCMKind::Signed16;
    else return NO;
    unsigned bytes = kind == obs::PCMKind::Float32 ? 4 : 2;
    unsigned channels = (f->mFormatFlags & kAudioFormatFlagIsNonInterleaved) ? 1 : f->mChannelsPerFrame;
    if (f->mBytesPerFrame != bytes * channels) return NO;
    obs::PCMBuffer buffers[8];
    for (unsigned i = 0; i < abl->mNumberBuffers; ++i)
        buffers[i] = {abl->mBuffers[i].mData, abl->mBuffers[i].mDataByteSize, abl->mBuffers[i].mNumberChannels};
    thread_local std::array<float, 8192> scratch;
    auto mapping = OBBusConsumer();
    if (!mapping || !mapping->data->readAudio(scratch.data(), frames, time, f->mSampleRate,
                                            uint64_t(OBNow() * 1000000))) return NO;
    return obs::mixSamples(scratch.data(), buffers, abl->mNumberBuffers, frames, kind, .65f, .75f);
}

CMSampleBufferRef OBCopyAudio(CMSampleBufferRef mic) {
    if (!OBEnabled() || !mic) return nullptr;
    if (CMGetAttachment(mic, CFSTR("local.xiaoguai.obsbridge.mixed"), nullptr)) return nullptr;
    auto format = CMSampleBufferGetFormatDescription(mic);
    if (!format || CMFormatDescriptionGetMediaType(format) != kCMMediaType_Audio) return nullptr;
    const AudioStreamBasicDescription *f = CMAudioFormatDescriptionGetStreamBasicDescription(format);
    CMItemCount frames = CMSampleBufferGetNumSamples(mic);
    if (!f || frames <= 0 || frames > 8192) return nullptr;
    alignas(AudioBufferList) std::array<uint8_t, offsetof(AudioBufferList, mBuffers) + sizeof(AudioBuffer) * 8> storage{};
    auto *abl = reinterpret_cast<AudioBufferList *>(storage.data());
    CMBlockBufferRef retained = nullptr;
    OSStatus rc = CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(mic, nullptr, abl, storage.size(),
        kCFAllocatorDefault, kCFAllocatorDefault, kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment, &retained);
    if (rc || !retained) return nullptr;
    std::vector<uint8_t> copies[8];
    if (abl->mNumberBuffers > 8) { CFRelease(retained); return nullptr; }
    for (unsigned i = 0; i < abl->mNumberBuffers; ++i) {
        const auto &b = abl->mBuffers[i];
        if (!b.mData || b.mDataByteSize > 8192 * 8 * 4) { CFRelease(retained); return nullptr; }
        copies[i].resize(b.mDataByteSize); memcpy(copies[i].data(), b.mData, b.mDataByteSize);
        abl->mBuffers[i].mData = copies[i].data();
    }
    // Host-clock scheduling is approximate at this private converter input.
    // True end-to-end audio latency must be measured on each device/build.
    double pts = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(mic));
    double now = OBNow();
    double when = std::isfinite(pts) && std::fabs(pts - now) < 2 ? pts : now;
    if (!OBMixABL(abl, (UInt32)frames, f, when)) { CFRelease(retained); return nullptr; }
    CMSampleTimingInfo timing{}; CMSampleBufferRef mixed = nullptr;
    rc = CMSampleBufferGetSampleTimingInfo(mic, 0, &timing);
    if (!rc) rc = CMSampleBufferCreate(kCFAllocatorDefault, nullptr, false, nullptr, nullptr,
                                      format, frames, 1, &timing, 0, nullptr, &mixed);
    if (!rc) rc = CMSampleBufferSetDataBufferFromAudioBufferList(mixed, kCFAllocatorDefault,
        kCFAllocatorDefault, kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment, abl);
    if (!rc) rc = CMSampleBufferSetDataReady(mixed);
    CFRelease(retained);
    if (rc) { if (mixed) CFRelease(mixed); return nullptr; }
    CFDictionaryRef attachments = CMCopyDictionaryOfAttachments(kCFAllocatorDefault, mic, kCMAttachmentMode_ShouldPropagate);
    if (attachments) { CMSetAttachments(mixed, attachments, kCMAttachmentMode_ShouldPropagate); CFRelease(attachments); }
    CMSetAttachment(mixed, CFSTR("local.xiaoguai.obsbridge.mixed"), kCFBooleanTrue, kCMAttachmentMode_ShouldPropagate);
    return mixed;
}
