# OBSBridge 0.2.3：只读媒体缓存 + 原子像素快照

目标：rootless 越狱 iOS 15.0–16.6，8 Plus / SE2。当前用户实测设备是 8 Plus / iOS 15.0.2。**这是修正源码，不是已通过完整手机直播验收的成品。**

## 已确认的故障

0.2.1 的 IMG_0083：TCP 收到 105930292 字节、视频解码 1605、音频 2512；媒体心跳 PID 9524、视频回调 5727、音频回调 250。实际替换与混音均为 0，媒体端 `IOSurfaceLookup(5)` 返回空。故障在跨进程共享，不是没有网络、没有解码或没有挂到系统输出节点。

此外发布数 0 / 失败数 0 不由映射失败自动解释。源码的六帧待播队列会在高帧率输入时淘汰每个尚未到 180 ms 显示时间的帧。本机 60 FPS 仿真复现旧策略发布 0，修正策略发布 289/300；这证明源码缺陷，不证明用户输入当时必为 60 FPS。

## 0.2.2 最新设备证据与修正边界

IMG_0084：解码视频 446 / 音频 700、共享发布 435 / 失败 0、时钟重置 0；媒体 PID 10128、UID/GID 501、视频回调 551 / 音频 121。仍未替换/混音，缓存 open(RW) 返回 errno=1。

这证明发布队列修正生效，媒体端的读写打开被系统拒绝。**不能仅凭该错误认定“只禁写、读一定允许”**。本版删除不必要的读取端写需求：O_RDONLY/PROT_READ；所有像素/尺寸是原子值，写者先失效序号再发布新序号，读者前后校验同一版本，不在只读页写租约。只读快照复制中遇到覆盖、停用或换流则丢弃，不使用撕裂帧。

若真机依然显示 open(RO) errno=1，则该路径的只读访问也被拒绝，需要实际系统拒绝日志或重新选择经过验证的 IPC，不应继续用 chmod 777、换 OBS 参数或仅凭猜测改路径。

## 本版实际修改

- 保持已经连接成功的 SpringBoard TCP / MPEG-TS / H.264 / AAC 接收，不改 OBS URL、容器或编码要求。
- 不再通过全局 IOSurface ID 传递控制或视频。改用插件自有文件的 MAP_SHARED 映射：固定布局控制面、3 槽原子像素/版本校验的 BGRA 数据、2 秒原子 PCM 环。
- 文件路径 `/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v4.dat`；大小 11827584 字节，权限 0660（创建者与继承的组），不授予其他用户写权限。消费者只使用 O_RDONLY / PROT_READ；不再更新共享租约。只读打开或映射失败时报告 errno，不绕过限制。
- 新文件先完整初始化再原子 rename；不会截短旧映射。校验普通文件、属主、禁止其他用户写、尺寸、会话与协议；O_NOFOLLOW 拒绝最后一级符号链接。旧映射随最后引用释放，不把旧进程的指针当 IPC。
- 输入帧在发布端转换成有界 BGRA（最多 1280×720 或 720×1280），复制到共享槽；媒体端只读复制成自己的 CVPixelBuffer，复制前后验证同一帧版本，再保持原相机样本尺寸/格式与方向处理。
- 12 帧有界待播队列：满时丢新帧，不再淘汰最早的待播帧。新增调度次数、队列长度、队首等待、丢帧与时钟重置计数。
- 未增加目标应用注入或 AVCapture 委托回退。系统入口仍是 BWNodeOutput emitSampleBuffer:；失败时透传真实输入。

## GitHub 编译

1. 上传 `OBSBridge-source-0.2.3.zip` 原文件，不用解压。
2. 用配套“GitHub工作流-0.2.3只读共享修正版.txt”覆盖仓库根 `.github/workflows/build-deb.yml`；ZIP 里的工作流不会自动替换仓库工作流。
3. 提交后在同一分支启动新的 Actions 运行。旧 0.2.1 工作流不接受 0.2.3 源码。
4. 下载 `OBSBridge-rootless-deb`，安装版本 0.2.3。包 ID 未变，作为升级安装。用 Dopamine 重启用户空间，使两模块均重新加载。

control、Makefile、FFmpeg 脚本保持 Unix LF；工作流也会在测试/打包前规范化 LF。完整 Theos/macOS 构建仍需由 Actions 实际执行。

## 验收

手机和电脑在可信局域网。解锁桌面，短按音量上再在 0.8 秒内短按音量下。填写电脑 IPv4，开始接收。OBS 保持已有 mpegts、libx264、AAC 48 kHz 设置；先使用 360×640 / 30 FPS 测试，不要直接长时间正式直播。

先看状态：TCP 字节与解码继续增长；共享发布增长；映射检查必须为“文件映射成功”。如果是 open(RO) / mmap 错误，截图其中 errno 与媒体 UID/GID，不能通过再改 OBS 编码解决。

再打开相机视频预览/短录像：真实视频回调与实际替换应增长，实际画面应是带标记的 OBS 源。然后用 OBS 播放声音，同时在手机麦克风旁说话/拍手，短录并回听两路；混音计数不是直播接收端验收的替代。

## 限制和隐私

- 文件映射是标准 IPC 机制，不代表 mediaserverd 的实际文件访问权限已经验证。本机 Windows 双进程测试不证明 iOS 沙盒允许访问该路径。
- 约 11.3 MiB 缓存会包含最近视频/音频，未加密。停止时清空当前可写的视频槽并清除 PCM，仍不能保证清除文件系统快照或崩溃残留；不是隐私隔离/安全擦除工具。不得共享此缓存文件；回传状态截图即可。
- 文件映射的磁盘写回、耗电、CPU 与热负载未测量。仅做低分辨率短测试，本版不承诺长时间稳定直播。
- 格式仍限制 BGRA/8-bit NV12 视频，packed Float32/Int16 PCM，最多 8 通道/8192 帧。其他路径或断流透传真实输入。
- TikTok/其他直播 SDK 是否经过支持的系统音频节点，需要真实两路声音验收；不承诺照片、深度、HDR、电话、AR 等。
- TCP 无加密，仅允许配置的电脑 IP，不要公网映射 5000 端口。

## 检查与依据

实际检查见 TEST_RESULTS.md。没有将本机测试称为完整手机功能通过。

- [Apple mmap 手册](https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man2/mmap.2.html)：MAP_SHARED 文件映射和失败 errno；不保证本设备沙盒权限。
- [Apple open 手册](https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man2/open.2.html)：O_RDWR/O_NOFOLLOW。
- [系统输出节点 POC](https://github.com/EthanArbuckle/vcam-ios/blob/main/Tweak.x)：仅作为节点研究依据，不当作本版实测结果。

未复制原 VCam deb 的实现或二进制。FFmpeg LGPL 分发材料见 THIRD_PARTY.md。
